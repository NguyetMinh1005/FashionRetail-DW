USE Fashion_Staging;
GO

-- =========================================================
-- 2.2.4. XÁC ĐỊNH QUY TẮC NGHIỆP VỤ ĐỐI VỚI DỮ LIỆU
-- Mục tiêu:
-- - Kiểm tra các điều kiện nghiệp vụ quan trọng
-- - Ghi nhận số dòng vi phạm
-- - Chưa xử lý/xóa dữ liệu tại bước này
-- =========================================================


-- =========================================================
-- R1. QUANTITY PHẢI > 0
-- =========================================================

SELECT
    COUNT(*) AS Violation_R1_Quantity
FROM raw.transactions
WHERE TRY_CONVERT(INT, Quantity) <= 0
   OR TRY_CONVERT(INT, Quantity) IS NULL;


-- =========================================================
-- R2. UNIT_PRICE PHẢI > 0
-- =========================================================

SELECT
    COUNT(*) AS Violation_R2_UnitPrice
FROM raw.transactions
WHERE TRY_CONVERT(DECIMAL(18,2), Unit_Price) <= 0
   OR TRY_CONVERT(DECIMAL(18,2), Unit_Price) IS NULL;


-- =========================================================
-- R3. DISCOUNT TRONG TRANSACTIONS PHẢI NẰM TRONG [0,1]
-- =========================================================

SELECT
    COUNT(*) AS Violation_R3_Discount
FROM raw.transactions
WHERE TRY_CONVERT(DECIMAL(18,4), Discount) < 0
   OR TRY_CONVERT(DECIMAL(18,4), Discount) > 1
   OR TRY_CONVERT(DECIMAL(18,4), Discount) IS NULL;


-- =========================================================
-- R4. PRODUCT_ID TRONG TRANSACTIONS PHẢI TỒN TẠI TRONG PRODUCTS
-- =========================================================

SELECT
    COUNT(*) AS Violation_R4_Product
FROM raw.transactions t
LEFT JOIN raw.products p
    ON t.Product_ID = p.Product_ID
WHERE p.Product_ID IS NULL;


-- =========================================================
-- R5. STORE_ID TRONG TRANSACTIONS PHẢI TỒN TẠI TRONG STORES
-- =========================================================

SELECT
    COUNT(*) AS Violation_R5_Store
FROM raw.transactions t
LEFT JOIN raw.stores s
    ON t.Store_ID = s.Store_ID
WHERE s.Store_ID IS NULL;


-- =========================================================
-- R6. EMPLOYEE_ID TRONG TRANSACTIONS PHẢI TỒN TẠI TRONG EMPLOYEES
-- =========================================================

SELECT
    COUNT(*) AS Violation_R6_Employee
FROM raw.transactions t
LEFT JOIN raw.employees e
    ON t.Employee_ID = e.Employee_ID
WHERE e.Employee_ID IS NULL;


-- =========================================================
-- R7. CUSTOMER_ID TRONG TRANSACTIONS PHẢI TỒN TẠI TRONG CUSTOMERS
-- =========================================================

SELECT
    COUNT(*) AS Violation_R7_Customer
FROM raw.transactions t
LEFT JOIN raw.customers c
    ON t.Customer_ID = c.Customer_ID
WHERE c.Customer_ID IS NULL;


-- =========================================================
-- R8. EMPLOYEE PHẢI THUỘC ĐÚNG STORE CỦA GIAO DỊCH
-- =========================================================

SELECT
    COUNT(*) AS Violation_R8_EmployeeStore
FROM raw.transactions t
JOIN raw.employees e
    ON t.Employee_ID = e.Employee_ID
WHERE t.Store_ID <> e.Store_ID;


-- =========================================================
-- R9. DISCOUNTS: START <= END
-- =========================================================

SELECT
    COUNT(*) AS Violation_R9_DiscountDate
FROM raw.discounts
WHERE TRY_CONVERT(DATE, [Start]) > TRY_CONVERT(DATE, [End])
   OR TRY_CONVERT(DATE, [Start]) IS NULL
   OR TRY_CONVERT(DATE, [End]) IS NULL;


-- =========================================================
-- R10. DISCONT TRONG BẢNG DISCOUNTS PHẢI NẰM TRONG [0,1]
-- =========================================================

SELECT
    COUNT(*) AS Violation_R10_Discont
FROM raw.discounts
WHERE TRY_CONVERT(DECIMAL(18,4), Discont) < 0
   OR TRY_CONVERT(DECIMAL(18,4), Discont) > 1
   OR TRY_CONVERT(DECIMAL(18,4), Discont) IS NULL;


-- =========================================================
-- R11. TRANSACTION_TYPE CHỈ ĐƯỢC LÀ SALE HOẶC RETURN
-- =========================================================

SELECT
    COUNT(*) AS Violation_R11_TransactionType
FROM raw.transactions
WHERE Transaction_Type NOT IN ('Sale', 'Return')
   OR Transaction_Type IS NULL;


-- =========================================================
-- R12. KIỂM TRA DẤU LINE_TOTAL THEO SALE / RETURN
-- Chưa dùng làm rule loại dữ liệu cho đến khi xác nhận kết quả
-- =========================================================

SELECT
    Transaction_Type,
    COUNT(*) AS TotalRows,
    SUM(CASE
            WHEN TRY_CONVERT(DECIMAL(18,2), Line_Total) < 0
            THEN 1 ELSE 0
        END) AS Negative_Line_Total,
    SUM(CASE
            WHEN TRY_CONVERT(DECIMAL(18,2), Line_Total) = 0
            THEN 1 ELSE 0
        END) AS Zero_Line_Total,
    SUM(CASE
            WHEN TRY_CONVERT(DECIMAL(18,2), Line_Total) > 0
            THEN 1 ELSE 0
        END) AS Positive_Line_Total
FROM raw.transactions
GROUP BY Transaction_Type;

-- =========================================================
-- R13. KIỂM TRA CÔNG THỨC LINE_TOTAL THEO LOẠI GIAO DỊCH
-- Sale   : Line_Total =  Unit_Price * Quantity * (1 - Discount)
-- Return : Line_Total = -Unit_Price * Quantity * (1 - Discount)
-- =========================================================

SELECT
    COUNT(*) AS Violation_R13_LineTotalFormula
FROM raw.transactions
WHERE ABS(
    TRY_CONVERT(DECIMAL(18,4), Line_Total)
    -
    CASE
        WHEN Transaction_Type = 'Sale' THEN
            TRY_CONVERT(DECIMAL(18,4), Unit_Price)
            * TRY_CONVERT(DECIMAL(18,4), Quantity)
            * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))

        WHEN Transaction_Type = 'Return' THEN
            -1 *
            TRY_CONVERT(DECIMAL(18,4), Unit_Price)
            * TRY_CONVERT(DECIMAL(18,4), Quantity)
            * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))
    END
) > 0.01;

-- =========================================================
-- R14. INVOICE_ID + LINE PHẢI DUY NHẤT
-- Dùng lại kết quả Duplicate của 2.2.3
-- =========================================================

WITH Dup AS
(
    SELECT
        Invoice_ID,
        Line,
        COUNT(*) AS Duplicate_Count
    FROM raw.transactions
    GROUP BY Invoice_ID, Line
    HAVING COUNT(*) > 1
)
SELECT
    COUNT(*) AS Duplicate_Groups,
    SUM(Duplicate_Count - 1) AS Extra_Duplicate_Rows
FROM Dup;


-- =========================================================
-- R15. KIỂM TRA INVOICE_TOTAL CÓ NHẤT QUÁN TRONG CÙNG HÓA ĐƠN
-- Một Invoice_ID không nên có nhiều Invoice_Total khác nhau
-- =========================================================

SELECT
    COUNT(*) AS Violation_R15_InvoiceTotal
FROM
(
    SELECT
        Invoice_ID
    FROM raw.transactions
    GROUP BY Invoice_ID
    HAVING COUNT(DISTINCT Invoice_Total) > 1
) x;


-- =========================================================
-- KẾT THÚC 2.2.4
-- Sau khi chạy:
-- 1. Ghi lại số dòng vi phạm từng Rule
-- 2. Rule nào 0 vi phạm => dữ liệu đạt rule
-- 3. Rule nào > 0 => đưa vào bảng Data Quality Rules
-- 4. Chưa DELETE/UPDATE dữ liệu tại bước này
-- =========================================================

-- =========================================================
-- KIỂM TRA CHI TIẾT R13
-- Xem Line_Total thực tế và Line_Total tính lại
-- =========================================================

SELECT TOP 50
    Invoice_ID,
    Line,
    Transaction_Type,
    Unit_Price,
    Quantity,
    Discount,
    Line_Total,

    CASE
        WHEN Transaction_Type = 'Sale' THEN
            TRY_CONVERT(DECIMAL(18,4), Unit_Price)
            * TRY_CONVERT(DECIMAL(18,4), Quantity)
            * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))

        WHEN Transaction_Type = 'Return' THEN
            -1 *
            TRY_CONVERT(DECIMAL(18,4), Unit_Price)
            * TRY_CONVERT(DECIMAL(18,4), Quantity)
            * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))
    END AS Expected_Line_Total,

    ABS(
        TRY_CONVERT(DECIMAL(18,4), Line_Total)
        -
        CASE
            WHEN Transaction_Type = 'Sale' THEN
                TRY_CONVERT(DECIMAL(18,4), Unit_Price)
                * TRY_CONVERT(DECIMAL(18,4), Quantity)
                * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))

            WHEN Transaction_Type = 'Return' THEN
                -1 *
                TRY_CONVERT(DECIMAL(18,4), Unit_Price)
                * TRY_CONVERT(DECIMAL(18,4), Quantity)
                * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))
        END
    ) AS Difference

FROM raw.transactions
WHERE ABS(
        TRY_CONVERT(DECIMAL(18,4), Line_Total)
        -
        CASE
            WHEN Transaction_Type = 'Sale' THEN
                TRY_CONVERT(DECIMAL(18,4), Unit_Price)
                * TRY_CONVERT(DECIMAL(18,4), Quantity)
                * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))

            WHEN Transaction_Type = 'Return' THEN
                -1 *
                TRY_CONVERT(DECIMAL(18,4), Unit_Price)
                * TRY_CONVERT(DECIMAL(18,4), Quantity)
                * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))
        END
    ) > 0.01
ORDER BY Difference DESC;

-- =========================================================
-- PHÂN TÍCH R13 THEO LOẠI GIAO DỊCH
-- =========================================================

WITH CheckLineTotal AS
(
    SELECT
        Transaction_Type,

        ABS(
            TRY_CONVERT(DECIMAL(18,4), Line_Total)
            -
            CASE
                WHEN Transaction_Type = 'Sale' THEN
                    TRY_CONVERT(DECIMAL(18,4), Unit_Price)
                    * TRY_CONVERT(DECIMAL(18,4), Quantity)
                    * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))

                WHEN Transaction_Type = 'Return' THEN
                    -1 *
                    TRY_CONVERT(DECIMAL(18,4), Unit_Price)
                    * TRY_CONVERT(DECIMAL(18,4), Quantity)
                    * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))
            END
        ) AS Difference

    FROM raw.transactions
)

SELECT
    Transaction_Type,
    COUNT(*) AS TotalRows,

    SUM(
        CASE WHEN Difference > 0.01
        THEN 1 ELSE 0 END
    ) AS Rows_Not_Match,

    SUM(
        CASE WHEN Difference <= 0.01
        THEN 1 ELSE 0 END
    ) AS Rows_Match

FROM CheckLineTotal
GROUP BY Transaction_Type;
USE Fashion_Staging;
GO

-- =========================================================
-- 2.2.5. PHÂN TÍCH DỮ LIỆU BẤT THƯỜNG
-- Chỉ khảo sát, chưa UPDATE/DELETE dữ liệu
-- =========================================================


-- =========================================================
-- A1. RETURN CÓ LINE_TOTAL KHÔNG KHỚP CÔNG THỨC GIẢ ĐỊNH
-- Return:
-- Line_Total ≈ -Unit_Price * Quantity * (1 - Discount)
-- =========================================================

SELECT
    COUNT(*) AS Abnormal_Return_LineTotal
FROM raw.transactions
WHERE Transaction_Type = 'Return'
  AND ABS(
        TRY_CONVERT(DECIMAL(18,4), Line_Total)
        -
        (
            -1
            * TRY_CONVERT(DECIMAL(18,4), Unit_Price)
            * TRY_CONVERT(DECIMAL(18,4), Quantity)
            * (1 - TRY_CONVERT(DECIMAL(18,4), Discount))
        )
      ) > 0.01;


-- =========================================================
-- A2. MỘT INVOICE_ID CÓ NHIỀU GIÁ TRỊ INVOICE_TOTAL
-- =========================================================

SELECT
    COUNT(*) AS Abnormal_InvoiceTotal
FROM
(
    SELECT Invoice_ID
    FROM raw.transactions
    GROUP BY Invoice_ID
    HAVING COUNT(DISTINCT Invoice_Total) > 1
) x;


-- =========================================================
-- A3. TRANSACTION_TYPE KHÔNG KHỚP TIỀN TỐ RET CỦA INVOICE
-- Kiểm tra tính nhất quán giữa mã hóa đơn và loại giao dịch
-- =========================================================

SELECT
    COUNT(*) AS Abnormal_RET_TransactionType
FROM raw.transactions
WHERE
       (Invoice_ID LIKE 'RET%' AND Transaction_Type <> 'Return')
    OR (Invoice_ID NOT LIKE 'RET%' AND Transaction_Type = 'Return');


-- =========================================================
-- A4. NUMBER_OF_EMPLOYEES TRONG STORES
-- KHÔNG KHỚP SỐ NHÂN VIÊN THỰC TẾ TRONG EMPLOYEES
-- =========================================================

WITH ActualEmployees AS
(
    SELECT
        Store_ID,
        COUNT(DISTINCT Employee_ID) AS Actual_Employees
    FROM raw.employees
    GROUP BY Store_ID
)
SELECT
    COUNT(*) AS Abnormal_Store_Employee_Count
FROM raw.stores s
LEFT JOIN ActualEmployees a
    ON s.Store_ID = a.Store_ID
WHERE
       TRY_CONVERT(INT, s.Number_of_Employees)
           <> ISNULL(a.Actual_Employees, 0)
    OR TRY_CONVERT(INT, s.Number_of_Employees) IS NULL;


-- Xem chi tiết nếu có chênh lệch
WITH ActualEmployees AS
(
    SELECT
        Store_ID,
        COUNT(DISTINCT Employee_ID) AS Actual_Employees
    FROM raw.employees
    GROUP BY Store_ID
)
SELECT
    s.Store_ID,
    s.Store_Name,
    s.Number_of_Employees AS Declared_Employees,
    ISNULL(a.Actual_Employees, 0) AS Actual_Employees
FROM raw.stores s
LEFT JOIN ActualEmployees a
    ON s.Store_ID = a.Store_ID
WHERE
       TRY_CONVERT(INT, s.Number_of_Employees)
           <> ISNULL(a.Actual_Employees, 0)
    OR TRY_CONVERT(INT, s.Number_of_Employees) IS NULL;


-- =========================================================
-- A5. DATE_OF_BIRTH KHÔNG CHUYỂN ĐƯỢC SANG KIỂU DATE
-- Chỉ kiểm tra những dòng không bị thiếu
-- =========================================================

SELECT
    COUNT(*) AS Abnormal_DateOfBirth
FROM raw.customers
WHERE NULLIF(LTRIM(RTRIM(Date_Of_Birth)), '') IS NOT NULL
  AND TRY_CONVERT(DATE, Date_Of_Birth) IS NULL;


-- =========================================================
-- A6. PRODUCTION_COST KHÔNG HỢP LỆ
-- Không phải số hoặc <= 0
-- Chỉ kiểm tra dòng có dữ liệu
-- =========================================================

SELECT
    COUNT(*) AS Abnormal_ProductionCost
FROM raw.products
WHERE NULLIF(LTRIM(RTRIM(Production_Cost)), '') IS NOT NULL
  AND
  (
       TRY_CONVERT(DECIMAL(18,2), Production_Cost) IS NULL
       OR TRY_CONVERT(DECIMAL(18,2), Production_Cost) <= 0
  );


-- =========================================================
-- TÓM TẮT:
--
-- A1: Return Line_Total bất thường
-- A2: Invoice_Total không nhất quán
-- A3: Invoice RET không khớp Transaction_Type
-- A4: Số nhân viên Store không khớp bảng Employees
-- A5: Date_Of_Birth sai định dạng
-- A6: Production_Cost không hợp lệ
--
-- Chưa xóa dữ liệu tại bước này.
-- Các kết quả sẽ làm cơ sở cho 2.3 Transform.
-- =========================================================